import Flutter 
import UIKit
import GoogleMaps // Google Maps를 임포트합니다.

@main
@objc class AppDelegate: FlutterAppDelegate {
  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
    // Google Maps API Key 설정
    GMSServices.provideAPIKey("AIzaSyCwiXZkn75jgJZfPEl-Ff8EpStl8G5VJHU") // 여기에 API 키를 입력하세요.

    GeneratedPluginRegistrant.register(with: self)
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }
}
