import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class FreeTalkDetailScreen extends StatefulWidget {
  final String postId;
  final String nickname;
  final String title;
  final String content;
  final Timestamp timestamp;
  final String postAuthorEmail;

  const FreeTalkDetailScreen({
    Key? key,
    required this.postId,
    required this.nickname,
    required this.title,
    required this.content,
    required this.timestamp,
    required this.postAuthorEmail,
  }) : super(key: key);

  @override
  State<FreeTalkDetailScreen> createState() => _FreeTalkDetailScreenState();
}

class _FreeTalkDetailScreenState extends State<FreeTalkDetailScreen> {
  final TextEditingController _commentController = TextEditingController();
  bool isAnonymous = true;
  String? nickname;

  @override
  void initState() {
    super.initState();
    _loadNickname();
  }

  Future<void> _loadNickname() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final doc = await FirebaseFirestore.instance.collection('users').doc(user.email).get();
    setState(() {
      nickname = doc.data()?['nickname'] ?? '익명';
    });
  }

  Future<void> _submitComment() async {
    final commentText = _commentController.text.trim();
    final user = FirebaseAuth.instance.currentUser;

    if (commentText.isEmpty || user == null) return;

    final userDoc = await FirebaseFirestore.instance.collection('users').doc(user.email).get();
    final userNickname = userDoc.exists ? userDoc['nickname'] ?? '익명' : '익명';

    await FirebaseFirestore.instance
        .collection('freeTalks')
        .doc(widget.postId)
        .collection('comments')
        .add({
      'userEmail': user.email,
      'isAnonymous': isAnonymous,
      'nickname': isAnonymous ? '익명' : userNickname,
      'content': commentText,
      'timestamp': FieldValue.serverTimestamp(),
    });

    _commentController.clear();
  }

  Future<void> _handleLikeDislike(bool isLike) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final email = user.email!;

    final postRef = FirebaseFirestore.instance
        .collection('freeTalks')
        .doc(widget.postId); // ✅ 수정된 경로

    final likeDoc = postRef.collection('likes').doc(email);
    final dislikeDoc = postRef.collection('dislikes').doc(email);

    final likeSnap = await likeDoc.get();
    final dislikeSnap = await dislikeDoc.get();

    if (isLike) {
      if (likeSnap.exists) {
        await likeDoc.delete(); // 좋아요 취소
      } else {
        await likeDoc.set({
          'userEmail': email,
          'timestamp': FieldValue.serverTimestamp(),
        });
        if (dislikeSnap.exists) await dislikeDoc.delete(); // 싫어요가 눌려있으면 취소
      }
    } else {
      if (dislikeSnap.exists) {
        await dislikeDoc.delete(); // 싫어요 취소
      } else {
        await dislikeDoc.set({
          'userEmail': email,
          'timestamp': FieldValue.serverTimestamp(),
        });
        if (likeSnap.exists) await likeDoc.delete(); // 좋아요가 눌려있으면 취소
      }
    }

    setState(() {}); // UI 갱신
  }




  String _formatTimestamp(Timestamp timestamp) {
    final dt = timestamp.toDate();
    return DateFormat('MM/dd HH:mm').format(dt);
  }

  @override
  Widget build(BuildContext context) {
    final postRef = FirebaseFirestore.instance.collection('freeTalks').doc(widget.postId);
    final commentsRef = postRef.collection('comments');

    return Scaffold(
      backgroundColor: Colors.white, // ✅ 여기에 추가!
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        title: const Text(
          '자유게시판',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold,color: Colors.black),
        ),
        centerTitle: true,
        leading: IconButton(
          icon: Image.asset(
            'assets/images/Back-Navs.png',
            width: 70,
            height: 70,
          ),
          onPressed: () => Navigator.of(context).pop(),
          padding: const EdgeInsets.only(left: 8), // 조정 가능
        ),
      ),

      body: Column(
        children: [
          // 게시물 본문
          Container(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.nickname,
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                Text(_formatTimestamp(widget.timestamp),
                    style: const TextStyle(color: Colors.grey, fontSize: 12)),
                const SizedBox(height: 12),
                Text(widget.title,
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                const SizedBox(height: 6),
                Text(widget.content, style: const TextStyle(fontSize: 15)),
                const SizedBox(height: 12),
                Row(
                  children: [
                    StreamBuilder<QuerySnapshot>(
                      stream: postRef.collection('likes').snapshots(),
                      builder: (context, likeSnap) {
                        if (!likeSnap.hasData) return const SizedBox();
                        return StreamBuilder<QuerySnapshot>(
                          stream: postRef.collection('dislikes').snapshots(),
                          builder: (context, dislikeSnap) {
                            if (!dislikeSnap.hasData) return const SizedBox();

                            final likes = likeSnap.data!.docs.length;
                            final dislikes = dislikeSnap.data!.docs.length;

                            final currentUser = FirebaseAuth.instance.currentUser;
                            final hasLiked = likeSnap.data!.docs.any((doc) => doc.id == currentUser?.email);
                            final hasDisliked = dislikeSnap.data!.docs.any((doc) => doc.id == currentUser?.email);

                            return Row(
                              children: [
                                IconButton(
                                  icon: Icon(
                                    hasLiked ? Icons.thumb_up : Icons.thumb_up_alt_outlined,
                                    color: hasLiked ? Colors.blue : Colors.grey,
                                  ),
                                  onPressed: () => _handleLikeDislike(true),
                                ),
                                Text('$likes'),
                                const SizedBox(width: 16),
                                IconButton(
                                  icon: Icon(
                                    hasDisliked ? Icons.thumb_down : Icons.thumb_down_alt_outlined,
                                    color: hasDisliked ? Colors.red : Colors.grey,
                                  ),
                                  onPressed: () => _handleLikeDislike(false),
                                ),
                                Text('$dislikes'),
                              ],
                            );
                          },
                        );
                      },
                    ),


                  ],
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          // 댓글 리스트
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: commentsRef.orderBy('timestamp').snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
                final comments = snapshot.data!.docs;
                final currentUserEmail = FirebaseAuth.instance.currentUser?.email;

                return ListView.builder(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  itemCount: comments.length,
                  itemBuilder: (context, index) {
                    final doc = comments[index];
                    final data = doc.data() as Map<String, dynamic>;
                    final timestamp = data['timestamp'] as Timestamp?;
                    final commentEmail = data['userEmail'];
                    final isAnonymousComment = data['isAnonymous'] == true;
                    final isAuthor = commentEmail == widget.postAuthorEmail;
                    final isMyComment = commentEmail == currentUserEmail;

                    final commentNickname = data['nickname'] ?? '익명';
                    final displayName = isAnonymousComment ? '익명' : commentNickname;
                    final fullName = isAuthor ? '$displayName (글쓴이)' : displayName;

                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 6),
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF5F5F5),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(
                                  fullName,
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: isAuthor ? Colors.cyan : Colors.black,
                                  ),
                                ),
                                const Spacer(),
                                if (isMyComment)
                                  GestureDetector(
                                    onTap: () async {
                                      final shouldDelete = await showDialog<bool>(
                                        context: context,
                                        builder: (ctx) => AlertDialog(
                                          backgroundColor: Colors.white,
                                          title: const Text('댓글 삭제'),
                                          content: const Text('정말 이 댓글을 삭제하시겠습니까?'),
                                          actions: [
                                            TextButton(
                                              onPressed: () => Navigator.of(ctx).pop(false),
                                              child: const Text('취소'),
                                            ),
                                            TextButton(
                                              onPressed: () => Navigator.of(ctx).pop(true),
                                              child: const Text('삭제', style: TextStyle(color: Colors.red)),
                                            ),
                                          ],
                                        ),
                                      );
                                      if (shouldDelete == true) {
                                        await commentsRef.doc(doc.id).delete();
                                      }
                                    },
                                    child: const Icon(Icons.delete_outline, color: Colors.grey, size: 20),
                                  ),
                              ],
                            ),
                            const SizedBox(height: 4),
                            Text(data['content']),
                            if (timestamp != null)
                              Align(
                                alignment: Alignment.bottomRight,
                                child: Text(
                                  _formatTimestamp(timestamp),
                                  style: const TextStyle(fontSize: 12, color: Colors.grey),
                                ),
                              ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),

          // 댓글 입력창
          Padding(
            padding: const EdgeInsets.all(10),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xFFF7F7F7),
                borderRadius: BorderRadius.circular(16),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        isAnonymous = !isAnonymous;
                      });
                    },
                    child: Row(
                      children: [
                        Icon(
                          isAnonymous
                              ? Icons.check_box
                              : Icons.check_box_outline_blank,
                          color: Colors.red,
                        ),
                        const SizedBox(width: 4),
                        const Text('익명'),
                      ],
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: TextField(
                      controller: _commentController,
                      decoration: const InputDecoration(
                        hintText: '댓글을 입력하세요.',
                        border: InputBorder.none,
                        isDense: true,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.send, color: Colors.red),
                    onPressed: _submitComment,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
