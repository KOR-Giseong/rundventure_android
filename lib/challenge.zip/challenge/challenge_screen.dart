import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:work/challenge/FreeTalk_Chat_Screen.dart';
import 'package:work/challenge/challenge_screen/navigation_bar.dart' as custom;
import 'package:firebase_auth/firebase_auth.dart';
import 'chat_room_screen.dart';
import 'components/challenge_form.dart';
import 'free_talk_form.dart';

class ChallengeScreen extends StatefulWidget {
  const ChallengeScreen({Key? key}) : super(key: key);

  @override
  State<ChallengeScreen> createState() => _ChallengeScreenState();
}

class _ChallengeScreenState extends State<ChallengeScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  Future<int> _getLikeCount(String postId) async {
    final snapshot = await FirebaseFirestore.instance
        .collection('freeTalks')
        .doc(postId)
        .collection('likes')
        .get();

    return snapshot.size;
  }

  @override
  void initState() {
    _tabController = TabController(length: 2, vsync: this);
    super.initState();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<String> _getNickname(String encodedEmail) async {
    try {
      String decodedEmail = encodedEmail.replaceAll('_at_', '@').replaceAll('_dot_', '.');
      DocumentSnapshot userDoc = await FirebaseFirestore.instance.collection('users').doc(decodedEmail).get();
      if (userDoc.exists && userDoc.data() != null) {
        return userDoc['nickname'] ?? '익명';
      }
    } catch (e) {
      print("닉네임 가져오기 실패: $e");
    }
    return '익명';
  }

  bool _isWithin24Hours(Timestamp? timestamp) {
    if (timestamp == null) return false;
    final now = DateTime.now();
    final postTime = timestamp.toDate();
    return now.difference(postTime).inHours < 24;
  }

  Widget _buildChallengePost(DocumentSnapshot challenge, String nickname, BuildContext context) {
    final challengeId = challenge.id;
    final String title = challenge['name'] ?? '제목 없음';
    final String subtitle = "기간: ${challenge['duration']} | 거리: ${challenge['distance']}";
    final String time = (challenge['timestamp'] as Timestamp?)?.toDate().toLocal().toString().substring(0, 16) ?? "날짜 없음";

    return Column(
      children: [
        InkWell(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ChatRoomScreen(challengeId: challengeId)),
            );
          },
          child: Container(
            color: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(subtitle, style: TextStyle(fontSize: 14, color: Colors.grey[700])),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Text(nickname, style: TextStyle(color: Colors.grey[600], fontSize: 12)),
                    const SizedBox(width: 8),
                    Text(time, style: TextStyle(color: Colors.grey[600], fontSize: 12)),
                  ],
                )
              ],
            ),
          ),
        ),
        Divider(height: 1, thickness: 0.5, color: Colors.grey[300]),
      ],
    );
  }

  Widget _buildFreeTalkPost(DocumentSnapshot post, String nickname, int likeCount) {
    final String title = post['title'] ?? '제목 없음';
    final String content = post['content'] ?? '';
    final String time = (post['timestamp'] as Timestamp?)?.toDate().toLocal().toString().substring(0, 16) ?? "날짜 없음";

    return Column(
      children: [
        InkWell(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => FreeTalkDetailScreen(
                  postId: post.id,
                  nickname: nickname,
                  title: title,
                  content: content,
                  timestamp: post['timestamp'],
                  postAuthorEmail: post['userEmail'],
                ),
              ),
            );
          },
          child: Container(
            color: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(content, style: const TextStyle(fontSize: 14, color: Colors.black87)),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Text(nickname, style: TextStyle(color: Colors.grey[600], fontSize: 12)),
                    const SizedBox(width: 8),
                    Text(time, style: TextStyle(color: Colors.grey[600], fontSize: 12)),
                    const SizedBox(width: 8),
                    Icon(Icons.thumb_up, size: 14, color: Colors.grey),
                    const SizedBox(width: 4),
                    Text('$likeCount', style: TextStyle(color: Colors.grey[600], fontSize: 12)),
                  ],
                )

              ],
            ),
          ),
        ),
        Divider(height: 1, thickness: 0.5, color: Colors.grey[300]),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Column(
            children: [
              const custom.NavigationBar(),
              const TabBar(
                labelColor: Colors.black,
                indicatorColor: Colors.black,
                tabs: [
                  Tab(text: "챌린지"),
                  Tab(text: "자유게시판"),
                ],
              ),
              Expanded(
                child: TabBarView(
                  children: [
                    // 챌린지 탭
                    StreamBuilder<QuerySnapshot>(
                      stream: FirebaseFirestore.instance
                          .collection('challenges')
                          .orderBy('timestamp', descending: true)
                          .snapshots(),
                      builder: (context, snapshot) {
                        if (!snapshot.hasData) {
                          return const Center(child: CircularProgressIndicator());
                        }

                        final docs = snapshot.data!.docs;

                        return ListView(
                          children: [
                            ...docs.map((doc) {
                              return FutureBuilder<String>(
                                future: _getNickname(doc['userEmail']),
                                builder: (context, snapshot) {
                                  final nickname = snapshot.data ?? '익명';
                                  return _buildChallengePost(doc, nickname, context);
                                },
                              );
                            }).toList(),
                            const SizedBox(height: 80),
                          ],
                        );
                      },
                    ),

                    // 자유게시판 탭
                    StreamBuilder<QuerySnapshot>(
                      stream: FirebaseFirestore.instance
                          .collection('freeTalks')  // 'freeTalks' 컬렉션
                          .doc(FirebaseAuth.instance.currentUser?.email?.replaceAll('@', '_at_').replaceAll('.', '_dot_') ?? '')  // 현재 로그인한 사용자의 이메일을 사용
                          .collection('posts')  // 'posts' 서브 컬렉션에서 게시물 불러오기
                          .orderBy('timestamp', descending: true)  // 최신 순으로 정렬
                          .snapshots(),
                      builder: (context, snapshot) {
                        if (!snapshot.hasData) {
                          return const Center(child: CircularProgressIndicator());
                        }

                        final docs = snapshot.data!.docs;

                        return ListView(
                          children: [
                            ...docs.map((doc) {
                              return FutureBuilder<String>(
                                future: _getNickname(doc['userEmail']),
                                builder: (context, nickSnap) {
                                  final nickname = nickSnap.data ?? '익명';
                                  return FutureBuilder<int>(
                                    future: _getLikeCount(doc.id),  // 좋아요 수 가져오기
                                    builder: (context, likeSnap) {
                                      final likeCount = likeSnap.data ?? 0;
                                      return _buildFreeTalkPost(doc, nickname, likeCount);
                                    },
                                  );
                                },
                              );
                            }).toList(),
                            const SizedBox(height: 80),
                          ],
                        );
                      },
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const FreeTalkForm()),
            );
          },
          label: const Text("글쓰기"),
          icon: const Icon(Icons.edit),
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      ),
    );
  }
}
