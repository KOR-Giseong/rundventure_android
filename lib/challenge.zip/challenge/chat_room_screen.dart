// 같은 import 생략 없이 유지
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

class ChatRoomScreen extends StatefulWidget {
  final String challengeId;
  const ChatRoomScreen({Key? key, required this.challengeId}) : super(key: key);

  @override
  State<ChatRoomScreen> createState() => _ChatRoomScreenState();
}

class _ChatRoomScreenState extends State<ChatRoomScreen> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final picker = ImagePicker();
  final uuid = Uuid();

  File? _selectedImage;

  String decodeEmail(String encodedEmail) {
    return encodedEmail.replaceAll('_at_', '@').replaceAll('_dot_', '.');
  }

  Future<String> _getNickname(String email) async {
    final doc = await FirebaseFirestore.instance.collection('users').doc(email).get();
    if (doc.exists) {
      return doc['nickname'] ?? '알 수 없음';
    }
    return '알 수 없음';
  }


  Future<void> _pickImage() async {
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _selectedImage = File(pickedFile.path);
      });
    }
  }

  Future<String?> _uploadImage(String docId) async {
    if (_selectedImage == null) return null;
    final ref = FirebaseStorage.instance
        .ref()
        .child('chat_images')
        .child('$docId.jpg');
    await ref.putFile(_selectedImage!);
    return await ref.getDownloadURL();
  }

  Future<void> _sendMessage() async {
    final message = _messageController.text.trim();
    if (message.isEmpty && _selectedImage == null) return;

    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final encodedEmail = user.email!.replaceAll('.', '_dot_').replaceAll('@', '_at_');
    final userDoc = await FirebaseFirestore.instance.collection('users').doc(user.email!).get();

    final userName = userDoc.exists ? userDoc['nickname'] ?? '알 수 없음' : '알 수 없음';
    final userEmail = user.email!;
    final docId = "${userEmail}_${DateTime.now().millisecondsSinceEpoch}_${uuid.v4()}";
    final imageUrl = await _uploadImage(docId);

    await FirebaseFirestore.instance
        .collection('challenges')
        .doc(widget.challengeId)
        .collection('comments')
        .doc(docId)
        .set({
      'comment': message,
      'timestamp': FieldValue.serverTimestamp(),
      'userName': userName,
      'userEmail': userEmail,
      'imageUrl': imageUrl,
    });

    await FirebaseFirestore.instance.collection('notifications').add({
      'type': 'comment',
      'challengeId': widget.challengeId,
      'userEmail': userEmail,
      'userName': userName,
      'message': message,
      'imageUrl': imageUrl,
      'timestamp': FieldValue.serverTimestamp(),
    });

    _messageController.clear();
    setState(() {
      _selectedImage = null;
    });
    _scrollToBottom();
  }

  Future<void> _toggleParticipation(bool join, List currentParticipants) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final updatedList = List<String>.from(currentParticipants);
    if (join) {
      if (!updatedList.contains(user.email)) {
        updatedList.add(user.email!);
      }
    } else {
      updatedList.remove(user.email);
    }

    await FirebaseFirestore.instance
        .collection('challenges')
        .doc(widget.challengeId)
        .update({'participants': updatedList});
  }

  void _scrollToBottom() {
    Future.delayed(Duration(milliseconds: 300), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  String _formatTimestamp(Timestamp timestamp) {
    final date = timestamp.toDate();
    return DateFormat('yyyy.MM.dd HH:mm').format(date);
  }

  Widget _buildChallengeInfo(DocumentSnapshot challengeDoc) {
    final data = challengeDoc.data() as Map<String, dynamic>;
    final title = data['name'] ?? '제목 없음';
    final distance = data['distance'] ?? '';
    final duration = data['duration'] ?? '';
    final slogan = data['slogan'] ?? '🔥 목표를 향해 함께 달려요!';
    final encodedEmail = data['userEmail'] ?? '';
    final timestamp = data['timestamp'] as Timestamp?;
    final startDate = timestamp?.toDate() ?? DateTime.now();
    final formattedDate = timestamp != null ? _formatTimestamp(timestamp) : '';
    final userNameFuture = FirebaseFirestore.instance
        .collection('users')
        .doc(decodeEmail(encodedEmail))
        .get();
    final participants = List<String>.from(data['participants'] ?? []);
    final endDate = startDate.add(Duration(days: int.tryParse(duration) ?? 7));
    final now = DateTime.now();
    final daysLeft = endDate.difference(now).inDays;
    final progress = ((now.difference(startDate).inSeconds) /
        (endDate.difference(startDate).inSeconds))
        .clamp(0.0, 1.0);

    final userEmail = FirebaseAuth.instance.currentUser?.email;
    final hasJoined = userEmail != null && participants.contains(userEmail);

    return FutureBuilder<DocumentSnapshot>(
      future: userNameFuture,
      builder: (context, snapshot) {
        final writer = snapshot.hasData && snapshot.data!.exists
            ? snapshot.data!['nickname'] ?? '알 수 없음'
            : '알 수 없음';

        return Card(
          margin: EdgeInsets.all(16),
          color: Colors.blue[50],
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                SizedBox(height: 10),
                Text("🎯 $slogan", style: TextStyle(fontSize: 16)),
                SizedBox(height: 8),
                Text("🏁 거리: $distance km", style: TextStyle(fontSize: 15)),
                Text("⏱️ 기간: $duration일", style: TextStyle(fontSize: 15)),
                SizedBox(height: 8),
                LinearProgressIndicator(value: progress, backgroundColor: Colors.grey[300]),
                SizedBox(height: 4),
                Text("⏳ 남은 기간: ${daysLeft >= 0 ? '$daysLeft일' : '완료됨'}"),
                SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("👥 참여 인원: ${participants.length}명"),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: hasJoined ? Colors.white : Colors.blueAccent,
                        foregroundColor: hasJoined ? Colors.redAccent : Colors.white,
                        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                        textStyle: TextStyle(fontWeight: FontWeight.w600),
                      ),
                      onPressed: () => _toggleParticipation(!hasJoined, participants),
                      child: Text(hasJoined ? '참여 취소' : '참여하기'),
                    ),
                  ],
                ),
                SizedBox(height: 6),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("글쓴이: $writer", style: TextStyle(color: Colors.grey[600], fontSize: 12)),
                    Text(formattedDate, style: TextStyle(color: Colors.grey[600], fontSize: 12)),
                  ],
                )
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildComment(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    final comment = data['comment'] ?? '';
    final userEmail = data['userEmail'] ?? '';
    final timestamp = data['timestamp'] as Timestamp?;
    final imageUrl = data['imageUrl'];
    final timeText = timestamp != null ? _formatTimestamp(timestamp) : '';
    final isMyComment = FirebaseAuth.instance.currentUser?.email == userEmail;

    return FutureBuilder<String>(
      future: _getNickname(userEmail),
      builder: (context, snapshot) {
        final userName = snapshot.data ?? '알 수 없음';

        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // nickname + 삭제 버튼
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    userName,
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: Colors.grey[800]),
                  ),
                  if (isMyComment)
                    GestureDetector(
                      onTap: () async {
                        await FirebaseFirestore.instance
                            .collection('challenges')
                            .doc(widget.challengeId)
                            .collection('comments')
                            .doc(doc.id)
                            .delete();
                      },
                      child: Icon(Icons.close, size: 16, color: Colors.grey[500]),
                    ),
                ],
              ),
              SizedBox(height: 6),
              if (imageUrl != null)
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: AspectRatio(
                    aspectRatio: 4 / 3,
                    child: Image.network(imageUrl, fit: BoxFit.cover),
                  ),
                ),
              if (imageUrl != null) SizedBox(height: 8),
              if (comment.isNotEmpty)
                Text(comment, style: TextStyle(fontSize: 15, height: 1.4)),
              SizedBox(height: 6),
              Align(
                alignment: Alignment.bottomRight,
                child: Text(timeText, style: TextStyle(fontSize: 11, color: Colors.grey[500])),
              ),
              Divider(height: 24, thickness: 0.5, color: Colors.grey[300]),
            ],
          ),
        );
      },
    );
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Image.asset('assets/images/Back-Navs.png', width: 70, height: 70),
          onPressed: () => Navigator.pop(context),
          padding: const EdgeInsets.only(left: 8), // 조정 가능
        ),
        title: Text("챌린지",
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black)),
      ),
      body: SafeArea(
        child: StreamBuilder<DocumentSnapshot>(
          stream: FirebaseFirestore.instance
              .collection('challenges')
              .doc(widget.challengeId)
              .snapshots(),
          builder: (context, challengeSnapshot) {
            if (!challengeSnapshot.hasData) {
              return Center(child: CircularProgressIndicator());
            }

            return Column(
              children: [
                _buildChallengeInfo(challengeSnapshot.data!),
                Expanded(
                  child: StreamBuilder<QuerySnapshot>(
                    stream: FirebaseFirestore.instance
                        .collection('challenges')
                        .doc(widget.challengeId)
                        .collection('comments')
                        .orderBy('timestamp', descending: false)
                        .snapshots(),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) {
                        return Center(child: CircularProgressIndicator());
                      }

                      final comments = snapshot.data!.docs;
                      WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());

                      return comments.isEmpty
                          ? Center(child: Text("아직 댓글이 없습니다."))
                          : ListView(
                        controller: _scrollController,
                        children: comments.map(_buildComment).toList(),
                      );
                    },
                  ),
                ),
                if (_selectedImage != null)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Row(
                      children: [
                        Expanded(child: Image.file(_selectedImage!)),
                        IconButton(
                          icon: Icon(Icons.close),
                          onPressed: () => setState(() => _selectedImage = null),
                        )
                      ],
                    ),
                  ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.grey[100],
                    border: Border(top: BorderSide(color: Colors.grey[300]!)),
                  ),
                  child: Row(
                    children: [
                      IconButton(
                        icon: Icon(Icons.image_outlined, color: Colors.grey[600]),
                        onPressed: _pickImage,
                      ),
                      Expanded(
                        child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 12),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: Colors.grey[300]!),
                          ),
                          child: TextField(
                            controller: _messageController,
                            style: TextStyle(fontSize: 14),
                            decoration: InputDecoration(
                              hintText: "댓글을 입력하세요",
                              border: InputBorder.none,
                            ),
                          ),
                        ),
                      ),
                      IconButton(
                        icon: Icon(Icons.send_rounded, color: Colors.blueAccent),
                        onPressed: _sendMessage,
                      ),
                    ],
                  ),
                )

              ],
            );
          },
        ),
      ),
    );
  }
}
