import 'package:flutter/material.dart';

class ChallengeContent extends StatelessWidget {
  const ChallengeContent({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: Image.asset(
            "assets/images/image 17.png",
            width: double.infinity,
            fit: BoxFit.cover,
          ),
        ),
        const SizedBox(height: 16),
        ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: Image.asset(
            "assets/images/image 18.png",
            width: double.infinity,
            fit: BoxFit.cover,
          ),
        ),
      ],
    );
  }
}